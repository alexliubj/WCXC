//
//  MagazineMainViewController.m
//  iTotemMinFramework
//
//  Created by Alex.Liu on 2014-06-19.
//
//

#import "MagazineMainViewController.h"
#import "MagDetailsViewController.h"
#import "MagCell.h"
#import "BigImageCell.h"

#import "DemoDataRequest.h"


@interface MagazineMainViewController ()
{
    BOOL                        _loading;
    NSInteger                   _limit;
}

@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *indicator;


@end


@implementation MagazineMainViewController


@synthesize tableView = _tableView;

- (void)viewDidUnload
{
    [self setTableView:nil];
    [self setIndicator:nil];
    [super viewDidUnload];
}

- (void)showIndicator:(BOOL)show
{
    if (show) {
        self.indicator.hidden = FALSE;
        [self.indicator startAnimating];
    }
    else {
        self.indicator.hidden = TRUE;
        [self.indicator stopAnimating];
    }
}


-(void)getAllArticleByIssueId:(int)issueId
{
    NSDictionary *params = @{@"articleIssue": [NSString stringWithFormat:@"%d",issueId]};
    [GetAllArticlesRequest requestWithParameters:params withIndicatorView:self.view withCancelSubject:@"GetAllArticlesRequest" onRequestFinished:^(ITTBaseDataRequest *request){
        
        ITTDINFO(@"request successed");
        
    }];
}

-(void)getAllCommentsByArticleId
{
    NSDictionary *params = @{@"articleID": @"1"};
    [GetAllCommentsByArticleRequest requestWithParameters:params withIndicatorView:self.view withCancelSubject:@"GetAllCommentsByArticleRequest" onRequestFinished:^(ITTBaseDataRequest *request){
        
        ITTDINFO(@"request successed");
        
    }];
}

-(void)postCommentToArticle
{
    NSDictionary *params = @{@"articleID": @"1",
                             @"memberID": @"1",
                             @"commentContent": @"好文章啊不贵！"};
    [PostACommentRequest requestWithParameters:params withIndicatorView:self.view withCancelSubject:@"PostACommentRequest" onRequestFinished:^(ITTBaseDataRequest *request){
        
        ITTDINFO(@"request successed");
        
    }];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 3;
}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"RestCell";
    MagCell *restCell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (restCell == nil) {
        restCell = [MagCell loadFromXib];
    }
    
    //  newMagazine.url = [_images objectAtIndex:indexPath.row];
    return restCell;
}

// Called after the user changes the selection.
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    MagDetailsViewController *canDanVC=[[MagDetailsViewController alloc] initWithNibName:@"MagDetailsViewController" bundle:nil];
    [self.navigationController pushViewController:canDanVC animated:YES];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"杂志";
    
    [self performSelector:@selector(getApplicationListDataRequest) withObject:nil afterDelay:0.04];
    
 //   [self getAllArticleByIssueId:0];
  //  [self getAllCommentsByArticleId];
  //  [self postCommentToArticle];
    
    // Do any additional setup after loading the view from its nib.
}



- (void)setDataDic:(NSDictionary *)resultDic
{
    [self refreshDataDone];
    [self loadMoreDataDone];
 //   [_applicationManager removeAllObjects];
//    if (_applicationManager.kRefreshType == kRefreshTypeDown) {
//        NSArray *applications = resultDic[KEY_APPLICATION];
//        if ([applications count] >= 1) {
//            //            如果返回参数有limit和count
//            //            int pageSize = [[resultDic objectForKey:@"limit"] intValue];
//            //            int resultCount = [[resultDic objectForKey:@"count"] intValue];
//            //             如果返回参数没有limit和count 根据情况自定义
//            [_applicationManager updatePageIndexWithResultCount:[applications count] pageSize:PAGE_COUNT];
//            [_applicationManager addObjectsFromArray:applications];
//            if ([applications count] < PAGE_COUNT) {
//            }else{
//                [_tableView setLoadMoreViewHidden:NO];
//            }
//        }
//    }
//    else {
      //  [self loadMoreDataDone];
        
        
    //    [_tableView setLoadMoreViewHidden:YES];

//    }
}

- (void)sendGetApplicationDataRequest
{
    if (!_loading) {
        _loading = TRUE;
//        NSString *limit = [NSString stringWithFormat:@"%d", _limit];
//        [ApplicationSearchDataRequest requestWithParameters:@{@"limit": limit}
//                                          withIndicatorView:self.view
//                                          withCancelSubject:APPLICATION_LIST_REQUEST_CANCEL_SUBJECT
//                                             onRequestStart:^(ITTBaseDataRequest *request) {
//                                             }
//                                          onRequestFinished:^(ITTBaseDataRequest *request) {
//                                              if ([request isSuccess]) {
//                                                  [self setDataDic:request.handleredResult];
//                                                  [self.tableView reloadData];
//                                                  _loading = FALSE;
//                                              }
//                                          }
//                                          onRequestCanceled:^(ITTBaseDataRequest *request) {
//                                              if (_applicationManager.kRefreshType == kRefreshTypeDown) {
//                                                  [self refreshDataDone];
//                                              }else{
//                                                  [self loadMoreDataDone];
//                                              }
//                                              _loading = FALSE;
//                                          }
//                                            onRequestFailed:^(ITTBaseDataRequest *request) {
//                                                if (_applicationManager.kRefreshType == kRefreshTypeDown) {
//                                                    [self refreshDataDone];
//                                                }else{
//                                                    [self loadMoreDataDone];
//                                                }
//                                                _loading = FALSE;
//                                            }];
    }
}

- (void)getApplicationListDataRequest
{
    //_applicationManager.kRefreshType = kRefreshTypeDown;
    _limit = 10;
    [self sendGetApplicationDataRequest];
}

-(void)loadMoreApplicationListDataRequest
{
  //  _applicationManager.kRefreshType = kRefreshTypeUp;
    _limit += 10;
    [self sendGetApplicationDataRequest];
}


#pragma mark - ITTPullTableViewDelegate
- (void)pullTableViewDidTriggerRefresh:(ITTPullTableView *)pullTableView
{
    [_tableView setRefreshViewHidden:NO];
    ITTDINFO(@"pullTableViewDidTriggerRefresh");
    [self getApplicationListDataRequest];
}

- (void)pullTableViewDidTriggerLoadMore:(ITTPullTableView *)pullTableView
{
    ITTDINFO(@"pullTableViewDidTriggerLoadMore");
    [_tableView setLoadMoreViewHidden:NO];
    [self loadMoreApplicationListDataRequest];
}

- (void)loadMoreDataDone
{
    /*
     *Code to actually load more data goes here.
     */
    _tableView.pullTableIsLoadingMore = NO;
   // _applicationManager.kRefreshType = kRefreshTypeNone;
}

- (void)refreshDataDone
{
    /*
     *Code to actually refresh goes here.
     */
   // _applicationManager.kRefreshType = kRefreshTypeNone;
    _tableView.pullLastRefreshDate = [NSDate date];
    _tableView.pullTableIsRefreshing = NO;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

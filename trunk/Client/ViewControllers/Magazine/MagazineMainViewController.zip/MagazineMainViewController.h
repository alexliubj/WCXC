//
//  MagazineMainViewController.h
//  iTotemMinFramework
//
//  Created by Alex.Liu on 2014-06-19.
//
//

#import <UIKit/UIKit.h>
#import "ITTBaseDataRequest.h"
#import "ITTPullTableView.h"


@interface MagazineMainViewController : UIViewController<DataRequestDelegate,ITTPullTableViewDelegate>


@end
